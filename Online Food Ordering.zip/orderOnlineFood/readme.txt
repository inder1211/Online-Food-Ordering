to run this project:

-> create a database in phpmyadmin and import the file from SQL -> onlinefoodorder.sql

-> add your phpmyadmin credentials in connection -> connect.php file.

-> visit localhost/orderOnlineFood/ 


For admin panel:

-> visit localhost/orderOnlineFood/admin
	username: admin
	password: 1234

